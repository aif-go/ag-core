package client

const (
	HertzClientPropertiesPrefix = "kitex.client"
)

type HertzClientProperties struct {
	KeepAlive bool `value:"${keepAlive:true}"`

	// Timeout for establishing a connection to server. unit: ms
	DialTimeout int `value:"${dialTimeout:1000}"`

	// The max connection nums for each host
	MaxConnsPerHost int `value:"${maxConnsPerHost:512}"`

	// The max duration before idle keep-alive connection closed. unit: ms
	MaxIdleConnDuration int `value:"${maxIdleConnDuration:10000}"`

	// FIXME other options
}
