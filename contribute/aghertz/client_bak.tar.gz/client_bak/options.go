package client

import (
	"log/slog"

	"github.com/cloudwego/hertz/pkg/app/client"
	"github.com/cloudwego/hertz/pkg/common/config"
)

type (
	// ClientSuite is a suite of client options.
	ClientSuite interface {
		Options() []*config.ClientOption
	}

	// SimpleClientSuite is a simple implementation of ClientSuite.
	SimpleClientSuite struct {
		opts []*config.ClientOption
	}

	// MiddlewareOption is a middleware option.
	MiddlewareOption interface {
		MWF(client.Endpoint) client.Endpoint
		Order() int
	}

	// SimpleMiddlewareOption is a simple implementation of MiddlewareOption.
	SimpleMiddlewareOption struct {
		MWF   client.Endpoint
		Order int
	}
)

// Options implements ClientSuite.
func (s *SimpleClientSuite) Options() []*config.ClientOption {
	return s.opts
}

// WithClientSuite applies the client options suite to the client options.
func WithClientSuite(suite ClientSuite) config.ClientOption {
	copt := config.ClientOption{
		F: func(o *config.ClientOptions) {
			opts := []config.ClientOption{}
			for _, opt := range suite.Options() {
				opts = append(opts, *opt)
			}
			o.Apply(opts)
			// o.Apply(suite.Options())
		},
	}
	return copt
}

// HertzClientParams is the parameters for creating a hertz client.
type HertzClientParams struct {
	ClientOptions    []*config.ClientOption
	ClientMiddleware []client.Middleware
}

// NewHertzClient creates a new hertz client.
func NewHertzClient(params *HertzClientParams) (*client.Client, error) {
	// 应用客户端选项
	suite := &SimpleClientSuite{
		opts: params.ClientOptions,
	}
	c, err := client.NewClient(WithClientSuite(suite))
	if err != nil {
		slog.Error("failed to create hertz client", "err", err)
		return nil, err
	}

	// 应用客户端中间件 TODO 中间件应该有顺序，若params是通过fx注入的话，顺序无法保证
	c.Use(params.ClientMiddleware...)

	return c, nil
}
